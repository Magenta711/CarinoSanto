<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <h3>Dashboard</h3>
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <div class="card card-body">
                                <div class="row">
                                    <div class="col-md-7">
                                        <h1><?php echo e($num_users); ?></h1>
                                        <p>Users</p>
                                    </div>
                                    <div class="col-md-5">
                                        <i class="fas fa-user" style="font-size: 80px; color:rgba(0, 0, 0, 0.4);"></i>
                                    </div>
                                </div>
                                <div class="card-link text-center">
                                    <a class="btn btn-link btn-sm" href="<?php echo e(route('users')); ?>">Users</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="card card-body">
                                <div class="row">
                                    <div class="col-md-7">
                                        <h1><?php echo e($num_answers); ?></h1>
                                        <p>Answer</p>
                                    </div>
                                    <div class="col-md-5">
                                        <i class="fas fa-list-alt" style="font-size: 80px; color:rgba(0, 0, 0, 0.4);"></i>
                                    </div>
                                </div>
                                <div class="card-link text-center">
                                    <a class="btn btn-link btn-sm" href="<?php echo e(route('answers')); ?>">Answers</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="card card-body">
                                <div class="row">
                                    <div class="col-md-7">
                                        <h1><?php echo e($num_forms); ?></h1>
                                        <p>Forms</p>
                                    </div>
                                    <div class="col-md-5">
                                        <i class="fas fa-list-alt" style="font-size: 80px; color:rgba(0, 0, 0, 0.4);"></i>
                                    </div>
                                </div>
                                <div class="card-link text-center">
                                    <a class="btn btn-link btn-sm" href="<?php echo e(route('forms')); ?>">Forms</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\carino-santo\resources\views/home.blade.php ENDPATH**/ ?>