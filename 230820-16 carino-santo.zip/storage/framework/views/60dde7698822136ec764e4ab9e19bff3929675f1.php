<!-- Modal -->
<div class="modal fade" id="modal_edit_<?php echo e($item->id); ?>" data-backdrop="static" data-keyboard="false" tabindex="-1"
  aria-labelledby="modal_edit_<?php echo e($item->id); ?>Label" aria-hidden="true">
  <div class="modal-dialog  modal-dialog-scrollable modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modal_edit_<?php echo e($item->id); ?>Label">Edit user</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo e(route('users_update',$item->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
      <div class="modal-body text-left">
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control" name="name" value="<?php echo e($item->name); ?>" id="name" placeholder="Name">
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="text" class="form-control" name="email" value="<?php echo e($item->email); ?>" id="email" placeholder="Email">
        </div>
        <div class="form-group">
            <label for="roles">Role</label>
            <select name="roles" id="roles" class="form-control">
                <option selected disabled></option>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e(($item->getRoleNames()[0] == $rol->name) ? 'selected' : ''); ?> value="<?php echo e($rol->id); ?>"><?php echo e($rol->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-sm btn-primary">Save</button>
      </div>
      </form>
    </div>
  </div>
</div><?php /**PATH C:\laragon\www\carino-santo\resources\views/users/includes/modals/edit.blade.php ENDPATH**/ ?>