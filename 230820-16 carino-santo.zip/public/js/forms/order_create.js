$(document).ready(function() {
    $('.checkbox').click(function () {
        item = this.id.split("_")[this.id.split("_").length - 2];
        n = 0;
        types = $('.checkeds_'+item);
        for (let i = 0; i < types.length; i++) {
            if (types[i].checked) {
                n++;
            }
        }
        $('#num_checked_'+item).val(n);
    });
});