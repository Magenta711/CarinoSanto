@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                
                <div class="card-body">
                    <div class="col-md-12">
                        <i class="fas fa-user"></i> Users
                    </div>
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Rol</th>
                                    <th>/</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($users as $item)
                                <tr>
                                    <td>{{$item->id}}</td>
                                    <td>{{$item->name}}</td>
                                    <td>{{$item->email}}</td>
                                    <td>{{$item->getRoleNames()[0]}}</td>
                                    <td>
                                        <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#modal_show_{{$item->id}}">Show</button>
                                        <button class="btn btn-sm btn-success" data-toggle="modal" data-target="#modal_edit_{{$item->id}}">Edit</button>
                                    </td>
                                </tr>
                                @include('users.includes.modals.show')
                                @include('users.includes.modals.edit')
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    {{$users->links()}}
                    <hr>
                    <div class="row">
                        <div class="col-md-12">
                            <button class="btn btn-sm btn-block btn-success"  data-toggle="modal" data-target="#modal_create">Create</button>
                            @include('users.includes.modals.create')
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection