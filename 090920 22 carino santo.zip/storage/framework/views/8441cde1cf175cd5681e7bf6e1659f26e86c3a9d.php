<?php $__env->startSection('content'); ?>
<div class="container">
    <?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="row">
                        <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <div class="col-md-3 col-6 mb-5">
                                <img src="https://carinosanto.com/wp-content/uploads/2020/07/logoheader.png" class="card-img-top" alt="...">
                                <div class="card-img-overlay text-right">
                                    <?php if(Auth::user()->hasPermissionTo('Ver formularios')): ?>
                                        <div class="dropdown">
                                            <button class="btn btn-sm btn-secondary dropdown-toggle" type="button" id="optionsForm_<?php echo e($item->id); ?>" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                                            <div class="dropdown-menu" aria-labelledby="optionsForm_<?php echo e($item->id); ?>">
                                                <?php if(Auth::user()->hasPermissionTo('Ver respuestas del cliente propias') || Auth::user()->hasPermissionTo('Ver todas las respuestas')): ?>
                                                <a href="<?php echo e(route('forms_answer',$item->id)); ?>" class="dropdown-item"><i class="fas fa-list-alt"></i> <?php echo e(__('Answers')); ?></a>
                                                <?php endif; ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Ver formularios')): ?>
                                                <a href="<?php echo e(route('forms_show',$item->id)); ?>" class="dropdown-item"><i class="fas fa-eye"></i> <?php echo e(__('Show')); ?></a>
                                                <?php endif; ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Editar formularios')): ?>
                                                <a href="<?php echo e(route('forms_edit',$item->id)); ?>" class="dropdown-item"><i class="fas fa-edit"></i> <?php echo e(__('Edit')); ?></a>
                                                <?php endif; ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Eliminar formularios')): ?>
                                                <button class="dropdown-item" data-toggle="modal" data-target="#modal_delete_<?php echo e($item->id); ?>"><i class="fas fa-trash-alt"></i> <?php echo e(__('Delete')); ?></button>
                                                <?php endif; ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Copiar url de su formulario')): ?> 
                                                <div class="dropdown-item input-group">
                                                    <input type="text" class="form-control" id="url_<?php echo e($item->id); ?>" value="<?php echo e(config('app.url')); ?>/answer/<?php echo e($item->token); ?>/<?php echo e(Auth::user()->token); ?>" name="myURL_<?php echo e($item->id); ?>">
                                                    <div class="input-group-append">
                                                        <button class="btn btn-outline-secondary copy-url" id="copy_url_<?php echo e($item->id); ?>" onclick="copy_url(<?php echo e($item->id); ?>)" type="button"><i class="fas fa-copy"></i></button>
                                                    </div>
                                                </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="card-footer">
                                    <h5 class="card-title"><?php echo e($item->name); ?></h5>
                                    <small class="text-muted"><?php echo e($item->updated_at); ?></small>
                                </div>
                            </div>
                            <?php echo $__env->make('forms.includes.modals.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php echo e($forms->links()); ?>

                    <hr>
                    <div class="row">
                        <div class="col-md-12">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Crear formularios')): ?>
                            <a href="<?php echo e(route('form_create')); ?>" class="btn btn-sm btn-primary btn-block"><?php echo e(__('Create')); ?></a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        function copy_url(item){
            document.getElementById('url_'+item).select();
            document.execCommand("copy");
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\carino-santo\resources\views/forms/index.blade.php ENDPATH**/ ?>