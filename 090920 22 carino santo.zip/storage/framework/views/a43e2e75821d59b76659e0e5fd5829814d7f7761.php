<?php switch($question->type):
case ('1'): ?>
        <?php echo e(" "); ?>

        <p class="p-answer"><?php echo e(answerQuestion($id,$question)); ?></p>
        <?php break; ?>
    <?php case ('2'): ?>
        <p class="p-answer"><?php echo str_replace("\n", '</br>', addslashes(answerQuestion($id,$question))); ?></p>
        <?php break; ?>
    <?php case ('3'): ?>
        <p class="p-answer"><?php echo e((answerQuestion($id,$question))); ?></p>
        <?php break; ?>
    <?php case ('4'): ?>
        <p class="p-answer"><?php echo answerQuestion($id,$question); ?></p>
        <?php break; ?>
    <?php case ('5'): ?>
        <p class="p-answer"><?php echo e(answerQuestion($id,$question)); ?></p>
        <?php break; ?>
    <?php case ('6'): ?>
        <p><?php echo answerQuestion($id,$question); ?></p>
        <?php break; ?>
    <?php case ('7'): ?>
        <p class="p-answer"><?php echo e(answerQuestion($id,$question)); ?></p>
        <?php break; ?>
    <?php case ('8'): ?>
        <p class="p-answer"><?php echo e(answerQuestion($id,$question)); ?></p>
        <?php break; ?>
    <?php default: ?>
    
<?php endswitch; ?><?php /**PATH C:\laragon\www\carino-santo\resources\views/answers/includes/answer.blade.php ENDPATH**/ ?>