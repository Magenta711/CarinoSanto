<?php switch($question->type):
case ('1'): ?>
        <?php echo e(" "); ?>

        <p><p><?php echo e(hasAnswerQuestion($question,$id)); ?></p></p>
        <?php break; ?>
    <?php case ('2'): ?>
        <p><?php echo str_replace("\n", '</br>', addslashes(hasAnswerQuestion($question,$id))); ?></p>
        <?php break; ?>
    <?php case ('3'): ?>
        <p><?php echo e((hasAnswerQuestion($question,$id))); ?></p>
        <?php break; ?>
    <?php case ('4'): ?>
        <p><?php echo hasAnswerQuestion($question,$id); ?></p>
        <?php break; ?>
    <?php case ('5'): ?>
        <?php echo e(hasAnswerQuestion($question,$id)); ?>

        <?php break; ?>
    <?php case ('6'): ?>
        <?php echo e(hasAnswerQuestion($question,$id)); ?>

        <?php break; ?>
    <?php case ('7'): ?>
        <p><?php echo e(hasAnswerQuestion($question,$id)); ?></p>
        <?php break; ?>
    <?php case ('8'): ?>
        <p><?php echo e(hasAnswerQuestion($question,$id)); ?></p>
        <?php break; ?>
    <?php default: ?>
        
<?php endswitch; ?><?php /**PATH C:\laragon\www\carino-santo\resources\views/orders/includes/answer.blade.php ENDPATH**/ ?>