<?php
    $m = 0;
?>
<?php switch($question->type):
    case (1): ?>
    <div class="form-group" id="text-option">
        <input type="text" readonly name="text[]" id="text" class="form-control">
    </div>
        <?php break; ?>
    <?php case (2): ?>
        <div class="form-group" id="textarea-option">
            <textarea name="textarea[]" readonly id="textarea" cols="30" rows="1" class="form-control"></textarea> 
        </div>
        <?php break; ?>
    <?php case (3): ?>
        <div id="radio-option">
            <div class="form-group">
                <div id="option_destion_<?php echo e($n); ?>" class="option-new">
                    <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $m++;
                    ?>
                        <div id="option-radio_<?php echo e($n); ?>_<?php echo e($m); ?>" class="custom-control custom-radio option-radio_<?php echo e($n); ?>">
                            <input type="radio" id="radio" name="radio[]" class="custom-control-input">
                            <label class="custom-control-label" for="radio">
                                <div class="input-group mb-3">
                                    <input type="text" name="text_radio[]" id="text-radio" class="form-control" value="<?php echo e($option->option); ?>" placeholder="Option" aria-describedby="button-addon2">
                                    <div class="input-group-append">
                                        <button class="btn btn-sm btn-delete-option-radio" id="delete_option_radio_<?php echo e($n); ?>_<?php echo e($m); ?>" type="button" id="button-addon2"><i class="fas fa-times"></i></button>
                                    </div>
                                </div>
                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <input id="num_option_<?php echo e($n); ?>" type="hidden" name="num_option[]" value="<?php echo e($m); ?>">
            <button id="new_option_radio_<?php echo e($n); ?>" class="btn btn-sm btn-primary btn-block btn-new-option-radio"><i class="fas fa-plus"></i></button>
        </div>
        <?php break; ?>
    <?php case (4): ?>
        <div id="checkbox-option">
            <div class="form-group">
                <div id="option_destion_<?php echo e($n); ?>" class="option-new">
                    <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $m++;
                    ?>
                        <div id="option-checkbox_<?php echo e($n); ?>_<?php echo e($m); ?>" class="custom-control custom-checkbox option-checkbox_<?php echo e($n); ?>">
                            <input type="checkbox" name="checkbox" class="custom-control-input" id="customCheck1">
                            <label class="custom-control-label" for="customCheck1">
                                <div class="input-group mb-3">
                                    <input type="text" name="text_checkbox[]" id="text-checkbox" class="form-control" value="<?php echo e($option->option); ?>" placeholder="Option" aria-describedby="button-addon2">
                                    <div class="input-group-append">
                                        <button class="btn btn-sm btn-delete-option-checkbox" id="delete_option_checkbox_<?php echo e($n); ?>_<?php echo e($m); ?>" type="button" id="button-addon2"><i class="fas fa-times"></i></button>
                                    </div>
                                </div>
                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <input id="num_option_<?php echo e($n); ?>" type="hidden" name="num_option[]" value="<?php echo e($m); ?>">
            <button id="new_option_checkbox_<?php echo e($n); ?>" class="btn btn-sm btn-primary btn-block btn-new-option-checkbox"><i class="fas fa-plus"></i></button>
        </div>
        <?php break; ?>
    <?php case (5): ?>
        <div id="select-option">
            <div class="form-group">
                <div id="option_destion_<?php echo e($n); ?>" class="option-new">
                    <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $m++;
                    ?>
                        <div class="input-group mb-3" id="option-select_<?php echo e($n); ?>_<?php echo e($m); ?>">
                            <input type="text" name="text_select[]" id="text-select" class="form-control" value="<?php echo e($option->option); ?>" placeholder="Option" aria-describedby="button-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-sm btn-delete-option-select" id="delete_option_select_<?php echo e($n); ?>_<?php echo e($m); ?>" type="button" id="button-addon2"><i class="fas fa-times"></i></button>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <input id="num_option_<?php echo e($n); ?>" type="hidden" name="num_option[]" value="<?php echo e($m); ?>">
            <button id="new_option_select_<?php echo e($n); ?>" class="btn btn-sm btn-primary btn-block btn-new-option-select"><i class="fas fa-plus"></i></button>
        </div>
        <?php break; ?>
    <?php case (6): ?>
        <div class="form-group" id="file-option">
            <?php
                $m = 0;
            ?>
            <label for="">Permitir solo archivos de tipo</label>
            <div class="form-check">
                <input type="checkbox" <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($option->option == 'document'): ?> checked <?php $m++; ?> <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> value="document" name="type_file[]" class="form-check-input file_option_checked file_option_<?php echo e($n); ?>" id="file_option_1_<?php echo e($n); ?>">
                <label class="form-check-label" for="file_option_1_<?php echo e($n); ?>">
                    Documento
                </label>
            </div>
            <div class="form-check">
                <input type="checkbox" <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($option->option == 'worksheets'): ?> checked <?php $m++; ?> <?php endif; ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> value="worksheets" name="type_file[]" class="form-check-input file_option_checked file_option_<?php echo e($n); ?>" id="file_option_2_<?php echo e($n); ?>">
                <label class="form-check-label" for="file_option_2_<?php echo e($n); ?>">
                    Hoja de calculo
                </label>
            </div>
            <div class="form-check">
                <input type="checkbox" <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($option->option == 'pdf'): ?> checked <?php $m++; ?> <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> value="pdf" name="type_file[]" class="form-check-input file_option_checked file_option_<?php echo e($n); ?>" id="file_option_3_<?php echo e($n); ?>">
                <label class="form-check-label" for="file_option_3_<?php echo e($n); ?>">
                    PDF
                </label>
            </div>
            <div class="form-check">
                <input type="checkbox" <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($option->option == 'image'): ?> checked <?php $m++; ?> <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> value="image" name="type_file[]" class="form-check-input file_option_checked file_option_<?php echo e($n); ?>" id="file_option_4_<?php echo e($n); ?>">
                <label class="form-check-label" for="file_option_4_<?php echo e($n); ?>">
                    Imagen
                </label>
            </div>
            <div class="form-check">
                <input type="checkbox" <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($option->option == 'video'): ?> checked <?php $m++; ?> <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> value="video" name="type_file[]" class="form-check-input file_option_checked file_option_<?php echo e($n); ?>" id="file_option_5_<?php echo e($n); ?>">
                <label class="form-check-label" for="file_option_5_<?php echo e($n); ?>">
                    Video
                </label>
            </div>
            <input id="num_option_<?php echo e($n); ?>" type="hidden" name="num_option_file[]" value="<?php echo e($m); ?>">
        </div>
        <?php break; ?>
    <?php case (7): ?>
        <div class="form-group" id="date-option">
            <input type="date" readonly name="date[]" id="" class="form-control">
        </div>
        <?php break; ?>
    <?php case (8): ?>    
        <div class="form-group" id="time-option">
            <input type="time" readonly name="time[]" id="" class="form-control">
        </div>
        <?php break; ?>
    <?php default: ?>
        
<?php endswitch; ?>



<?php /**PATH C:\laragon\www\carino-santo\resources\views/forms/includes/elements_edit.blade.php ENDPATH**/ ?>