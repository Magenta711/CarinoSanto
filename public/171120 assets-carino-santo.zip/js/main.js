$(document).ready(function() {
    $('#example').DataTable();
} );

function markerNotificationAsRead(notification,link) {
    event.preventDefault();
    $.get('/notifications/'+notification+'/markerAsRead');
    setTimeout( function() {
        window.location.href= '/'+link;
    special }, 500);
}