<!-- Modal -->
<div class="modal fade" id="modal_edit_<?php echo e($item->id); ?>" data-backdrop="static" data-keyboard="false" tabindex="-1"
  aria-labelledby="modal_edit_<?php echo e($item->id); ?>Label" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modal_edit_<?php echo e($item->id); ?>Label"><?php echo e(__('Edit')); ?> rol</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo e(route('roles_update',$item->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="modal-body text-left">
          <div class="form-group">
            <strong><?php echo e(__('Name')); ?>:</strong>
            <input type="text" name="name" class="form-control" value="<?php echo e($item->name); ?>" placeholder="Nombre">
          </div>
          <div class="form-group">
            <strong><?php echo e(__('Permission')); ?>:</strong>
            <ul class="list-group">
              <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="list-group-item">
                <label>
                  <input type="checkbox" name="permission[]" class="name"  value="<?php echo e($value->id); ?>" <?php echo e($item->hasPermissionTo($value->name) ? 'checked' : ''); ?>>
                  <?php echo e($value->name); ?>

                </label>
              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
          <button class="btn btn-sm btn-success"><?php echo e(__('Update')); ?></button>
        </div>
      </form>
    </div>
  </div>
</div><?php /**PATH C:\laragon\www\carino-santo\resources\views/users/roles/includes/modals/edit.blade.php ENDPATH**/ ?>