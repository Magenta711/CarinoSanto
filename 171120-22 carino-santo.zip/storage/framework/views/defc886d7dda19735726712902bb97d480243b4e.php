<?php
    $n = 0;
?>
<?php echo $__env->make('forms.includes.elements_create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-sm-8">
                            <h2 id="form-tiple"><?php echo e($id->name); ?></h2>
                        </div>
                        <div class="col-sm-4 text-right">
                        </div>
                    </div>
                </div>
                <form action="<?php echo e(route('forms_update',$id->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="card-body">
                    <div class="card card-body mb-3">
                        <div class="form-group">
                            <input type="text" class="form-control" name="name" id="name" placeholder="<?php echo e(__('Form title')); ?>" value="<?php echo e($id->name); ?>">
                        </div>
                        <div class="form-group">
                            <textarea class="form-control" name="description" id="description" cols="30" rows="1" placeholder="><?php echo e(__('Description of the form')); ?>"><?php echo e($id->description); ?></textarea>
                        </div>
                    </div>
                    <div id="destino_question">
                        <?php $__currentLoopData = $id->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $n++;
                        ?>
                        <div class="card mb-3 questions" id="question_<?php echo e($n); ?>">
                            <input type="hidden" value="<?php echo e($question->id); ?>" name="question_id[]">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group card-title">
                                             <input type="question" value="<?php echo e($question->question); ?>" placeholder="Title of the question" name="question[]" id="question" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-6 type-options">
                                        <select name="type[]" id="type_<?php echo e($n); ?>" class="form-control types">
                                            <option>Selecciona una optión</option>
                                            <option <?php echo e($question->type == 1 ? 'selected' : ''); ?> value="1"><i class="fas fa-grip-lines"></i> Respuesta breve</option>
                                            <option <?php echo e($question->type == 2 ? 'selected' : ''); ?> value="2"><i class="fas fa-align-justify"></i> Párrafo</option>
                                            <option <?php echo e($question->type == 3 ? 'selected' : ''); ?> value="3"><i class="fas fa-dot-circle"></i> Opción multiple</option>
                                            <option <?php echo e($question->type == 4 ? 'selected' : ''); ?> value="4">Casilla de verificación</option>
                                            <option <?php echo e($question->type == 5 ? 'selected' : ''); ?> value="5">Lista desplegable</option>
                                            <option <?php echo e($question->type == 6 ? 'selected' : ''); ?> value="6">Cargar archivo</option>
                                            <option <?php echo e($question->type == 7 ? 'selected' : ''); ?> value="7">Fecha</option>
                                            <option <?php echo e($question->type == 8 ? 'selected' : ''); ?> value="8">Hora</option>
                                        </select>
                                    </div>
                                    <div class="col-md-12 detino" id="detino_<?php echo e($n); ?>">
                                        <?php echo $__env->make('forms.includes.elements_edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer text-right">
                                <button id="destroy_<?php echo e($n); ?>" class="btn btn-sm btn-destroy"><i class="fas fa-trash-alt"></i></button>
                                |
                                 <div class="form-check form-check-inline">
                                     <input class="form-check-input" name="required[]" type="checkbox" <?php echo e($question->required ? 'checked' : ''); ?> value="<?php echo e($n); ?>" id="required_<?php echo e($n); ?>">
                                     <label class="form-check-label" for="required_<?php echo e($n); ?>">
                                        <?php echo e(__('Required')); ?>

                                     </label>
                                 </div>
                                 |
                                 <button type="button" class="btn btn-sm"><i class="fas fa-ellipsis-v"></i></button>
                            </div>
                         </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <button class="btn btn-sm btn-primary btn-block" id="new-option"><i class="fas fa-plus"></i></button>
                    </div>
                    <div class="card-footer">
                        <button class="btn btn-sm btn-primary"><?php echo e(__('Update')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/forms/create.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\carino-santo\resources\views/forms/edit.blade.php ENDPATH**/ ?>