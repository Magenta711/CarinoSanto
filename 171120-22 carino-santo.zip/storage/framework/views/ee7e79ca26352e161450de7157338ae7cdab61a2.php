<?php
function answerQuestion($order, $question){
    $value = '';
    foreach ($order->answers as $answer){
        if ($answer->question_id == $question->id){
            if ($question->type == '1' || $question->type == '2' || $question->type == '7' || $question->type == '8'){
                $value = $answer->answer;
            }
            if ($question->type == '3' || $question->type == '5'){
                foreach ($question->options as $option){
                    if ($answer->answer == $option->id){
                        $value = $option->option;
                    }
                }
            }
            if ($question->type == '4'){
                foreach ($question->options as $option){
                    if ($answer->answer == $option->id){
                        $value = $value.$option->option.'<br>';
                    }
                }
            }
            if ($question->type == '6'){
                $exten = explode('.',$answer->answer);
                if ($exten[count($exten) - 1] == 'jpg' || $exten[count($exten) - 1] == 'png'){
                    $o = '<img src="/storage/upload/files/'.$answer->answer.'" width="100px" height="auto" class="img-rounded figure-img img-fluid rounded" alt="'.$answer->answer.'">';
                }else {
                    $o = $answer->answer;
                }
                $value = $value.'<a href="/storage/upload/files/'.$answer->answer.'" target="_blank" class="m-2">'.$o.'</a>';
            }
        }
    }
    return $value;
}
?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
                <div class="card-body">
                    <div class="card card-body mb-3">
                        <h3 class="card-title"><?php echo e($id->form->name); ?></h3>
                        <p class="card-text"><?php echo e($id->form->description); ?></p>
                        <span class="text-danger">*<?php echo e(__('Required')); ?></span>
                    </div>
                    <?php $__currentLoopData = $id->form->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card card-body mb-3">
                            <label class="label-text"> <?php echo e($question->question); ?> <span class="text-danger"><?php echo e($question->required ? '*' : ''); ?></span></label>
                            <?php echo $__env->make('answers.includes.answer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\carino-santo\resources\views/answers/show.blade.php ENDPATH**/ ?>