<?php

namespace App\Exports;

use App\Models\form;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\Exportable;
// use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\FromView;

class AnswersExport implements FromView
{
    use Exportable;

    private $id;
    
    public function forId($id){
        $this->id = $id;

        return $this;
    }

    public function view(): View
    {
        return view('forms.export',[
            'forms' => $this->id
        ]);
    }


    // public function query()
    // {
    //     return order::query();
    // }
}
