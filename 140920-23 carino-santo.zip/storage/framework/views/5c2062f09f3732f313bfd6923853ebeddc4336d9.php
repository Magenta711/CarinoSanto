<?php echo $__env->make('forms.includes.elements_create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
        <form action="<?php echo e(route('answers_store')); ?>" id="target" autocomplete="off" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="card card-body mb-3">
                <h3 class="card-title"><?php echo e($id->name); ?></h3>
                <p class="card-text"><?php echo e($id->description); ?></p>
                <span class="text-danger">*Required</span>
            </div>
            <input type="hidden" name="form" value="<?php echo e($id->token); ?>">
            <input type="hidden" name="user" value="<?php echo e($user); ?>">
            <?php $__currentLoopData = $id->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card card-body form-group mb-3">
                    <label class="label-text" for="input_<?php echo e($question->id); ?>"><?php echo e($question->question); ?> <span class="text-danger"><?php echo e($question->required ? '*' : ''); ?></span></label>
                    <?php echo $__env->make('forms.includes.type_controls', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="card card-body mb-3">
                <button class="btn btn-sm btn-primary btn-block btn-save">Save</button>
            </div>
        </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/upload.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/forms/order_create.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/forms/upload.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\carino-santo\resources\views/answers/create.blade.php ENDPATH**/ ?>