<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="card">
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <label for="" class="label-text">Name</label>
                        <p class="p-answer"><?php echo e(Auth::user()->name); ?></p>
                    </div>
                    <div class="form-group">
                        <label for="" class="label-text">Email</label>
                        <p class="p-answer"><?php echo e(Auth::user()->email); ?></p>
                    </div>
                    <div class="form-group">
                        <label for="" class="label-text">Role</label>
                        <p class="p-answer"><?php echo e(Auth::user()->getRoleNames()[0]); ?></p>
                    </div>
                    <hr>
                    <button class="btn btn-sm btn-primary btn-block" data-toggle="modal" data-target="#modal_edit">Edit</button>
                    <?php echo $__env->make('users.profile.includes.modals.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\carino-santo\resources\views/users/profile/index.blade.php ENDPATH**/ ?>