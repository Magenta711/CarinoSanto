<?php switch($question->type):
case ('1'): ?>
        <?php echo e(" "); ?>

        <input type="text" value="" name="text[]" placeholder="Respuesta" id="input_<?php echo e($question->id); ?>" class="form-control <?php echo e($question->required ? 'required' : ''); ?>">
        <?php break; ?>
    <?php case ('2'): ?>
        <textarea name="text_area[]" id="input_<?php echo e($question->id); ?>"  placeholder="Respuesta" class="form-control" cols="30" rows="2"></textarea>
        <?php break; ?>
    <?php case ('3'): ?>
        <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="custom-control custom-radio">
                <input type="radio" id="radio_<?php echo e($option->id); ?>" name="radio[<?php echo e($question->id); ?>]" value="<?php echo e($option->id); ?>" class="custom-control-input radios_<?php echo e($question->id); ?> <?php echo e($question->required ? 'required' : ''); ?>">
                <label class="custom-control-label" for="radio_<?php echo e($option->id); ?>">
                    <?php echo e($option->option); ?>

                </label>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php break; ?>
    <?php case ('4'): ?>
        <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="custom-control custom-checkbox">
                <input type="checkbox" name="checkbox[]" class="custom-control-input checkbox checkeds_<?php echo e($question->id); ?> <?php echo e($question->required ? 'required' : ''); ?>" value="<?php echo e($option->id); ?>" id="checkbox_<?php echo e($question->id); ?>_<?php echo e($option->id); ?>">
                <label class="custom-control-label" for="checkbox_<?php echo e($question->id); ?>_<?php echo e($option->id); ?>">
                    <?php echo e($option->option); ?>

                </label>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <input type="hidden" value="0" name="num_checked[]" id="num_checked_<?php echo e($question->id); ?>">
        <?php break; ?>
    <?php case ('5'): ?>
        <select name="select[]" id="input_<?php echo e($question->id); ?>" class="form-control <?php echo e($question->required ? 'required' : ''); ?>">
            <option disable>Selecciona una opción</option>
            <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($option->id); ?>"><?php echo e($option->option); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php break; ?>
    <?php case ('6'): ?>
        <button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#modal_upload_<?php echo e($question->id); ?>">Open</button>
        <?php echo $__env->make('forms.includes.modals.upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <input type="file" value="" name="file[]" id="input_<?php echo e($question->id); ?>" class="form-control <?php echo e($question->required ? 'required' : ''); ?>" accept=" <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php switch($option->option): case ('document'): ?> .doc,.docx <?php break; ?> <?php case ('worksheets'): ?> .xml <?php break; ?> <?php case ('pdf'): ?> .pdf <?php break; ?> <?php case ('image'): ?> image/* <?php break; ?> <?php case ('video'): ?> video/* <?php break; ?> <?php default: ?>
 <?php endswitch; ?> , <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> ">
        <?php break; ?>
    <?php case ('7'): ?>
        <input type="date" value="" id="input_<?php echo e($question->id); ?>" placeholder="Respuesta" class="form-control <?php echo e($question->required ? 'required' : ''); ?>" name="date[]">
        <?php break; ?>
    <?php case ('8'): ?>
        <input type="time" value="" id="input_<?php echo e($question->id); ?>" placeholder="Respuesta" class="form-control <?php echo e($question->required ? 'required' : ''); ?>" name="time[]">
        <?php break; ?>
    <?php default: ?>
<?php endswitch; ?><?php /**PATH C:\laragon\www\carino-santo\resources\views/forms/includes/type_controls.blade.php ENDPATH**/ ?>