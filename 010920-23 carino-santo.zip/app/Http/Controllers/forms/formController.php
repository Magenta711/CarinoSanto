<?php

namespace App\Http\Controllers\forms;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\form;
use App\Models\question;
use App\Models\detail_question;
use Illuminate\Support\Str;

class formController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('verified');
        $this->middleware('permission:Ver lista de formularios', ['only' => ['index']]);
        $this->middleware('permission:Ver formularios', ['only' => ['show']]);
        $this->middleware('permission:Crear formularios', ['only' => ['create','store']]);
        $this->middleware('permission:Editar formularios', ['only' => ['edit','update']]);
        $this->middleware('permission:Eliminar formularios', ['only' => ['delete']]);
        $this->middleware('permission:Ver todas las respuestas|Ver respuestas del cliente propias', ['only' => ['answer']]);
    }

    public function index()
    {
        $forms = form::orderBy('id','desc')->latest()->paginate(8);
        return view('forms.index',compact('forms'));
    }

    public function create ()
    {
        return view('forms.create');
    }

    public function store(Request $request)
    {
        $form = form::create([
            'name' => $request->name,
            'description' => $request->description,
            'responsible_id' => auth()->user()->id,
            'token' => Str::random(15)
        ]);
        $nO = 0;
        $nOtR = 0;
        $nOtC = 0;
        $nOtS = 0;
        $nF = 0;
        $nFt = 0;
        if($request->type){
            for ($i=0; $i < count($request->type); $i++) { 
                $required = false;
                if (in_array(($i+1), $request->required)) {
                    $required = true;
                }
                $question = question::create([
                    'form_id' => $form->id,
                    'question' => $request->question[$i],
                    'number' => $i,
                    'required' => $required,
                    'type' => $request->type[$i],
                ]);
                switch ($request->type[$i]) {
                    case "3":
                        if ($request->num_option[$nO]){
                            for ($j=0; $j < $request->num_option[$nO]; $j++) {
                                detail_question::create([
                                    'question_id' => $question->id,
                                    'num' => $j,
                                    'option' => $request->text_radio[$nOtR],
                                    'type' => $request->type[$i]
                                ]);
                                $nOtR++;
                            }
                        }
                        $nO++;
                        break;
                    case "4":
                        if ($request->num_option[$nO]) {
                            for ($j=0; $j < $request->num_option[$nO]; $j++) { 
                                detail_question::create([
                                    'question_id' => $question->id,
                                    'num' => $j,
                                    'option' => $request->text_checkbox[$nOtC],
                                    'type' => $request->type[$i]
                                ]);
                                $nOtC++;
                            }
                        }
                        $nO++;
                        break;
                    case "5":
                        if ($request->num_option[$nO]) {
                            for ($j=0; $j < $request->num_option[$nO]; $j++) { 
                                detail_question::create([
                                    'question_id' => $question->id,
                                    'num' => $j,
                                    'option' => $request->text_select[$nOtS],
                                    'type' => $request->type[$i]
                                ]);
                                $nOtS++;
                            }
                        }
                        $nO++;
                        break;
                    case "6":
                        if ($request->num_option_file[$nF]) {
                            for ($j=0; $j < $request->num_option_file[$nF]; $j++) { 
                                detail_question::create([
                                    'question_id' => $question->id,
                                    'num' => $j,
                                    'option' =>  $request->type_file[$nFt],
                                    'type' => $request->type[$i]
                                ]);
                                $nFt++;
                            }
                        }
                        $nF++;
                        break;
                    
                    default:
                        
                        break;
                }
            }
        }
        return redirect()->route('forms')->with('success','Se ha creado el formulario correctamente');
    }

    public function edit(form $id)
    {
        return view('forms.edit',compact('id'));
    }

    public function update(Request $request,form $id)
    {
        $id->update([
            'name' => $request->name,
            'description' => $request->description,
        ]);
        $nO = 0;
        $nOtR = 0;
        $nOtC = 0;
        $nOtS = 0;
        $nF = 0;
        $nFt = 0;
        foreach ($id->questions as $question) {
            foreach ($question->options as $option) {
                detail_question::where('id',$option->id)->delete();
            }
            question::where('id',$question->id)->delete();
        }
        if($request->type){
            for ($i=0; $i < count($request->type); $i++) { 
                $required = false;
                if (in_array(($i+1), $request->required)) {
                    $required = true;
                }
                $question = question::create([
                    'form_id' => $id->id,
                    'question' => $request->question[$i],
                    'number' => $i,
                    'required' => $required,
                    'type' => $request->type[$i],
                ]);
                switch ($request->type[$i]) {
                    case "3":
                        if ($request->num_option[$nO]){
                            for ($j=0; $j < $request->num_option[$nO]; $j++) {
                                detail_question::create([
                                    'question_id' => $question->id,
                                    'num' => $j,
                                    'option' => $request->text_radio[$nOtR],
                                    'type' => $request->type[$i]
                                ]);
                                $nOtR++;
                            }
                        }
                        $nO++;
                        break;
                    case "4":
                        if ($request->num_option[$nO]) {
                            for ($j=0; $j < $request->num_option[$nO]; $j++) { 
                                detail_question::create([
                                    'question_id' => $question->id,
                                    'num' => $j,
                                    'option' => $request->text_checkbox[$nOtC],
                                    'type' => $request->type[$i]
                                ]);
                                $nOtC++;
                            }
                        }
                        $nO++;
                        break;
                    case "5":
                        if ($request->num_option[$nO]) {
                            for ($j=0; $j < $request->num_option[$nO]; $j++) { 
                                detail_question::create([
                                    'question_id' => $question->id,
                                    'num' => $j,
                                    'option' => $request->text_select[$nOtS],
                                    'type' => $request->type[$i]
                                ]);
                                $nOtS++;
                            }
                        }
                        $nO++;
                        break;
                    case "6":
                        if ($request->num_option_file[$nF]) {
                            for ($j=0; $j < $request->num_option_file[$nF]; $j++) { 
                                detail_question::create([
                                    'question_id' => $question->id,
                                    'num' => $j,
                                    'option' =>  $request->type_file[$nFt],
                                    'type' => $request->type[$i]
                                ]);
                                $nFt++;
                            }
                        }
                        $nF++;
                        break;
                    
                    default:
                        
                        break;
                }
            }
        }
        return redirect()->route('forms')->with('success','Se ha actualizado el formulario correctamente');
    }

    public function delete(form $id)
    {
        $id->delete();
        return redirect()->route('forms')->with('success','Se ha eliminado el formulario correctamente');
    }

    public function show(form $id)
    {
        return view('forms.show',compact('id'));
    }

    public function answer(form $id)
    {
        if(auth()->user()->hasPermissionTo('Ver todas las respuestas')){
            $hasPermission = true;
        }else {
            if (auth()->user()->hasPermissionTo('Ver respuestas del cliente propias')) {
                $hasPermission = false;
            }
        }
        return view('forms.answer',compact('id','hasPermission'));
    }
}
