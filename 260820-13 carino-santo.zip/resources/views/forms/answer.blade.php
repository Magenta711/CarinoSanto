@extends('layouts.app')

@php
    function answerQuestion($order, $question){
        $value = '';
        foreach ($order->answers as $answer){
            if ($answer->question_id == $question->id){
                $value = $answer->answer;
                if ($question->type == '3' || $question->type == '5'){
                    foreach ($question->options as $option){
                        if ($answer->answer == $option->id){
                            $value = $option->option;
                        }
                    }
                }
                if ($question->type == '4'){
                    $value = '';
                    foreach ($question->options as $option){
                        if ($answer->answer == $option->id){
                            $value = $value.$option->option.'<br>';
                        }
                    }
                }
                if ($question->type == '6'){
                    $value = '<a href="/storage/upload/files/'.$answer->answer.'" target="_blank" class="btn btn-link">'.$answer->answer.'</a>';
                }
            }
        }
        return $value;
    }

    $already = false;
@endphp
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                
                <div class="card-body">
                    <div class="col-md-12">
                        <i class="fab fa-wpforms"></i> {{$id->name}}
                    </div>
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>User</th>
                                    @foreach ($id->questions as $question)
                                    <th>{{$question->question}}</th>
                                    @endforeach
                                    <th>/</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if (Auth::user()->hasPermissionTo('Ver todas las respuestas'))
                                @php
                                    $already = true;
                                @endphp
                                    @foreach ($id->orders as $order)
                                    <tr>
                                        <td>{{$order->id}}</td>
                                        <td>{{$order->user->name}}</td>
                                        @foreach ($id->questions as $question)
                                            <td>{!!answerQuestion($order,$question)!!}</td>
                                        @endforeach
                                        <td>
                                            <a href="{{route('answers_show',$order->id)}}" class="btn btn-sm btn-primary">Show</a>
                                        </td>
                                    </tr>
                                    @endforeach
                                @endif
                            </tbody>
                            <tbody>
                                @if (!$already && Auth::user()->hasPermissionTo('Ver respuestas del cliente propias'))
                                    @foreach ($id->orders as $order)
                                        @if (Auth::user()->id == $order->user_id)
                                            <tr>
                                                <td>{{$order->id}}</td>
                                                <td>{{$order->user->name}}</td>
                                                @foreach ($id->questions as $question)
                                                    <td>{!!answerQuestion($order,$question)!!}</td>
                                                @endforeach
                                                <td>
                                                    <a href="{{route('answers_show',$order->id)}}" class="btn btn-sm btn-primary">Show</a>
                                                </td>
                                            </tr>
                                        @endif
                                    @endforeach
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection