@switch($question->type)
@case('1')
        {{" "}}
        <p class="p-answer">{{hasAnswerQuestion($question,$id)}}</p>
        @break
    @case('2')
        <p class="p-answer">{!!str_replace("\n", '</br>', addslashes(hasAnswerQuestion($question,$id)))!!}</p>
        @break
    @case('3')
        <p class="p-answer">{{(hasAnswerQuestion($question,$id))}}</p>
        @break
    @case('4')
        <p class="p-answer">{!!hasAnswerQuestion($question,$id)!!}</p>
        @break
    @case('5')
        <p class="p-answer">{{hasAnswerQuestion($question,$id)}}</p>
        @break
    @case('6')
        <p><a href="/storage/upload/files/{{hasAnswerQuestion($question,$id)}}" target="_blank" class="btn btn-link">{{hasAnswerQuestion($question,$id)}}</a></p>
        @break
    @case('7')
        <p class="p-answer">{{hasAnswerQuestion($question,$id)}}</p>
        @break
    @case('8')
        <p class="p-answer">{{hasAnswerQuestion($question,$id)}}</p>
        @break
    @default
        
@endswitch