@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    <h3>Dashboard</h3>
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <div class="card card-body">
                                <div class="row">
                                    <div class="col-md-7">
                                        <h1>{{$num_users}}</h1>
                                        <p>Users</p>
                                    </div>
                                    <div class="col-md-5">
                                        <i class="fas fa-user" style="font-size: 80px; color:rgba(0, 0, 0, 0.4);"></i>
                                    </div>
                                </div>
                                <div class="card-link text-center">
                                    <a class="btn btn-link btn-sm" href="{{route('users')}}">Users</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="card card-body">
                                <div class="row">
                                    <div class="col-md-7">
                                        <h1>{{$num_answers}}</h1>
                                        <p>Answer</p>
                                    </div>
                                    <div class="col-md-5">
                                        <i class="fas fa-list-alt" style="font-size: 80px; color:rgba(0, 0, 0, 0.4);"></i>
                                    </div>
                                </div>
                                <div class="card-link text-center">
                                    <a class="btn btn-link btn-sm" href="{{route('answers')}}">Answers</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="card card-body">
                                <div class="row">
                                    <div class="col-md-7">
                                        <h1>{{$num_forms}}</h1>
                                        <p>Forms</p>
                                    </div>
                                    <div class="col-md-5">
                                        <i class="fab fa-wpforms" style="font-size: 80px; color:rgba(0, 0, 0, 0.4);"></i>
                                    </div>
                                </div>
                                <div class="card-link text-center">
                                    <a class="btn btn-link btn-sm" href="{{route('forms')}}">Forms</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection


{{-- 
Roles y permisos
Ver mis respuestas
Ver todas las respuestas
    Guardar nuevo valores obligatorios
    Guardar respuestas de radio
    Buscador de usuario
    Filtro para usuairios
    Filtro para respuestas
    Perfil [ foto ]
    Traducion
    Emails [nuevo pedido]
    Vista de respuestas generales
    Eliminar usuarios
    Eliminar respuestas
    Eliminar formularios
    Editar formularios
    No permitir loguear usuarios eliminados
    Ver usuarios eliminados
    Restaurar usuarios eliminados
    Notificaciones [nuevo usuario, nuevo formulario, nueva respuesta]
    pagina de Acerca
    validar formularios
--}}