<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-sm-12">
                            <i class="fas fa-user-friends"></i> Roles
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Rol</th>
                                    <th>/</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td>
                                         <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Ver permisos de roles')): ?> 
                                        <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#modal_show_<?php echo e($item->id); ?>">Show</button>
                                        <?php echo $__env->make('users.roles.includes.modals.show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                         <?php endif; ?> 
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Editar roles')): ?>
                                        <button class="btn btn-sm btn-success" data-toggle="modal" data-target="#modal_edit_<?php echo e($item->id); ?>">Edit</button>
                                        <?php echo $__env->make('users.roles.includes.modals.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Eliminar roles')): ?>
                                        <button class="btn btn-sm btn-danger" data-toggle="modal" data-target="#modal_delete_<?php echo e($item->id); ?>">Delete</button>
                                        <?php echo $__env->make('users.roles.includes.modals.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php echo e($roles->links()); ?>

                    <hr>
                    <div class="row">
                        <div class="col-md-12">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Crear roles')): ?>
                                <button class="btn btn-sm btn-success btn-block"  data-toggle="modal" data-target="#modal_create">Create</button>
                                <?php echo $__env->make('users.roles.includes.modals.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\carino-santo\resources\views/users/roles/index.blade.php ENDPATH**/ ?>