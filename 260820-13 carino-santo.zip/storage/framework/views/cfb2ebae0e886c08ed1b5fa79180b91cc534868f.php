<!-- Modal -->
<div class="modal fade" id="modal_show_<?php echo e($item->id); ?>" data-backdrop="static" data-keyboard="false" tabindex="-1"
  aria-labelledby="modal_show_<?php echo e($item->id); ?>Label" aria-hidden="true">
  <div class="modal-dialog  modal-dialog-scrollable modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modal_show_<?php echo e($item->id); ?>Label">Show user</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body text-left">
        <div class="form-group">
            <p class="font-weight-bold">Name</p>
            <p><?php echo e($item->name); ?></p>
        </div>
        <hr>
        <div class="form-group">
            <p class="font-weight-bold">Email</p>
            <p><?php echo e($item->email); ?></p>
        </div>
        <hr>
        <div class="form-group">
            <p class="font-weight-bold">Role</p>
            <p><?php echo e($item->getRoleNames()[0]); ?></p>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\laragon\www\carino-santo\resources\views/users/includes/modals/show.blade.php ENDPATH**/ ?>