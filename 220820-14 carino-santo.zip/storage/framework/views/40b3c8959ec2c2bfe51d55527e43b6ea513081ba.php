<!-- Modal -->
<div class="modal fade" id="modal_create" data-backdrop="static" data-keyboard="false" tabindex="-1"
  aria-labelledby="modal_createLabel" aria-hidden="true">
  <div class="modal-dialog  modal-dialog-scrollable modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modal_createLabel">Crear rol</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo e(route('roles_store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
      <div class="modal-body text-left">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-12">
              <div class="form-group">
                  <strong>Nombre:</strong>
                  <input type="text" name="name" class="form-control" placeholder="Nombre" value="<?php echo e(old('name')); ?>">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Permisos:</strong>
              <ul class="list-group">
                <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li class="list-group-item">
                    <input type="checkbox" name="permission[]" class="name" value="<?php echo e($value->id); ?>">
                    <?php echo e($value->name); ?>

                  </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-sm btn-primary">Save</button>
      </div>
      </form>
    </div>
  </div>
</div><?php /**PATH C:\laragon\www\carino-santo\resources\views/users/roles/includes/modals/create.blade.php ENDPATH**/ ?>