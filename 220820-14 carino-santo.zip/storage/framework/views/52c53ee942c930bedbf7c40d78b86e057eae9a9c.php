<?php switch($question->type):
    case ('1'): ?>
        <input type="text" id="input_<?php echo e($question->id); ?>" class="form-control">
        <?php break; ?>
    <?php case ('2'): ?>
        <textarea name="" id="input_<?php echo e($question->id); ?>" class="form-control" cols="30" rows="10"></textarea>
        <?php break; ?>
    <?php case ('3'): ?>
        <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="custom-control custom-radio">
                <input type="radio" id="radio_<?php echo e($option->id); ?>" name="radio[]" class="custom-control-input">
                <label class="custom-control-label" for="radio_<?php echo e($option->id); ?>">
                    <?php echo e($option->option); ?>

                </label>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php break; ?>
    <?php case ('4'): ?>
        <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="custom-control custom-checkbox">
                <input type="checkbox" name="checkbox" class="custom-control-input" id="checkbox_<?php echo e($option->id); ?>">
                <label class="custom-control-label" for="checkbox_<?php echo e($option->id); ?>">
                    <?php echo e($option->option); ?>

                </label>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php break; ?>
    <?php case ('5'): ?>
        <select name="" id="" class="form-control">
            <option value=""></option>
            <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=""><?php echo e($option->option); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php break; ?>
    <?php case ('6'): ?>
        <input type="file" class="form-control">
        <?php break; ?>
    <?php default: ?>
        
<?php endswitch; ?><?php /**PATH C:\laragon\www\carino-santo\resources\views/forms/includes/type_controls.blade.php ENDPATH**/ ?>