<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class form extends Model
{
    protected $fillable = [
        'name','description','responsible_id',
    ];

    public function questions()
    {
        return $this->hasMany(question::class, 'form_id', 'id');
    }
}
