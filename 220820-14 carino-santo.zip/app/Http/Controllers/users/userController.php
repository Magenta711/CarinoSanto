<?php

namespace App\Http\Controllers\users;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Str;
use App\User;
use DB;

class userController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('verified');
    }

    public function index()
    {
        $users = User::orderBy('id')->latest()->paginate(5);
        $roles = Role::get();
        return view('users.index',compact('users','roles'));
    }
    public function store(Request $request){
        $request->validate([
            'name' => ['required', 'string', 'max:100'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users,email'],
            'password' => ['required', 'string', 'min:8'],
            'roles' => ['required'],
        ]);
            
        $user=User::create($request->all());

        $user->update([
            'state' => 1,
            'password' => bcrypt($request->password),
            'token' => Str::random(60)
        ]);

        $user->assignRole($request->roles);

        return redirect()->route('users')->with('success','El usuario ha sido creado correctamente');
    }
    public function update(Request $request, User $id)
    {
        $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users,email,'.$id->id],
            'roles' => ['required'],
        ]);

        $id->update($request->all());

        // Notification
        DB::table('model_has_roles')->where('model_id',$id->id)->delete();

        $id->assignRole($request->roles);

        return redirect()->route('users')->with('success','El usuario ha sido editado correctamente');
        
    }
}
