<?php

namespace App\Http\Controllers\orders;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\order;

class orderController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('verified');
    }

    public function index()
    {
        $orders = order::orderBy('id')->latest()->paginate(5);
        return view('orders.index',compact('orders'));
    }
}
