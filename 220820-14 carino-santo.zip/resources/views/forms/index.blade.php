@extends('layouts.app')

@section('content')
<div class="container">
    @include('includes.alerts')
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-sm-8">
                            <h2><i class="fab fa-wpforms"></i> Forms</h2>
                        </div>
                        <div class="col-sm-4 text-right">
                            <a href="{{route('form_create')}}" class="btn btn-sm btn-primary">Crear</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    <div class="row">
                        @foreach ($forms as $item)
                            {{--  <a href="{{route('form_edit',1)}}" style="text-decoration: none;">  --}}
                            <div class="col-md-3 col-6 mb-5">
                                <img src="https://carinosanto.com/wp-content/uploads/2020/07/logoheader.png" class="card-img-top" alt="...">
                                <div class="card-img-overlay text-right">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-secondary dropdown-toggle" type="button" id="optionsForm_{{$item->id}}" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                                        <div class="dropdown-menu" aria-labelledby="optionsForm_{{$item->id}}">
                                            <a href="{{route('forms_show',$item->id)}}" class="dropdown-item"><i class="fas fa-eye"></i> View</a>
                                            <a href="{{route('forms_edit',$item->id)}}" class="dropdown-item"><i class="fas fa-edit"></i> Edit</a>
                                            <a href="{{route('forms_delete',$item->id)}}" class="dropdown-item"><i class="fas fa-trash-alt"></i> Delete</a>
                                            <div class="dropdown-item input-group">
                                                <input type="text" class="form-control" id="url_{{$item->id}}" value="{{config('app.url')}}/pedido/{{$item->id}}/{{Auth::user()->token}}" name="myURL_{{$item->id}}">
                                                <div class="input-group-append">
                                                    <button class="btn btn-outline-secondary copy-url" id="copy_url_{{$item->id}}" onclick="copy_url({{$item->id}})" type="button"><i class="fas fa-copy"></i></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <h5 class="card-title">{{$item->name}}</h5>
                                    <small class="text-muted">{{$item->updated_at}}</small>
                                </div>
                            </div>
                            {{--  </a>  --}}
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('js')
    <script>
        function copy_url(item){
            document.getElementById('url_'+item).select();
            document.execCommand("copy");
        }
    </script>
@endsection