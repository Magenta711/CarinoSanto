@switch($question->type)
    @case('1')
        <input type="text" id="input_{{$question->id}}" class="form-control">
        @break
    @case('2')
        <textarea name="" id="input_{{$question->id}}" class="form-control" cols="30" rows="10"></textarea>
        @break
    @case('3')
        @foreach ($question->options as $option)
            <div class="custom-control custom-radio">
                <input type="radio" id="radio_{{$option->id}}" name="radio[]" class="custom-control-input">
                <label class="custom-control-label" for="radio_{{$option->id}}">
                    {{$option->option}}
                </label>
            </div>
        @endforeach
        @break
    @case('4')
        @foreach ($question->options as $option)
            <div class="custom-control custom-checkbox">
                <input type="checkbox" name="checkbox" class="custom-control-input" id="checkbox_{{$option->id}}">
                <label class="custom-control-label" for="checkbox_{{$option->id}}">
                    {{$option->option}}
                </label>
            </div>
        @endforeach
        @break
    @case('5')
        <select name="" id="" class="form-control">
            <option value=""></option>
            @foreach ($question->options as $option)
                <option value="">{{$option->option}}</option>
            @endforeach
        </select>
        @break
    @case('6')
        <input type="file" class="form-control">
        @break
    @default
        
@endswitch