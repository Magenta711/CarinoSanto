<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Auth::routes(['register' => false]);
Auth::routes(['verify' => true]);
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('roles','users\RoleController@index')->name('roles');
Route::post('roles','users\RoleController@store')->name('roles_store');
Route::put('roles/{id}','users\RoleController@update')->name('roles_update');

Route::get('users','users\userController@index')->name("users");
Route::post('users','users\userController@store')->name("users_store");
Route::put('users/{id}','users\userController@update')->name("users_update");

Route::get('forms','forms\formController@index')->name("forms");
Route::get('forms/create','forms\formController@create')->name("form_create");
Route::get('forms/{id}','forms\formController@show')->name("forms_show");
Route::get('forms/{id}/edit','forms\formController@edit')->name("forms_edit");
Route::post('forms','forms\formController@store')->name("forms_store");
Route::put('forms/{id}','forms\formController@update')->name("forms_update");
Route::delete('forms/{id}','forms\formController@delete')->name("forms_delete");

Route::get('orders','orders\orderController@index')->name("orders");

Route::get('clients','clients\clientController@index')->name("clients");
